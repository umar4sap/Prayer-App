import React, {useState} from "react";
import {useDispatch} from "react-redux";
import {registerUser} from "../redux/users/users.actions";


let Assignment = () => {
    let dispatch = useDispatch();

    let [user , setUser] = useState({
       name : '',
        email : '',
        count : 1000,
        prayerType : null,
        duaDescription : ''

    });

    // handleInput
    let handleInput = (e) => {
      setUser({
          ...user,
          [e.target.name] : e.target.value
      })
    };

    // counterChange
    let counterChange = () => {
      setUser({
          ...user,
          count :  user.count > 0 ? user.count - 1 : null
      })
    };

    // submitUser
    let submitUser = (e) => {
        e.preventDefault();
        counterChange();
        dispatch(registerUser(user));
        alert(`Thank You ${user.name}`);
    };
  return(
      <React.Fragment>
          <div className="container mt-5">
              <div className="row">
                  <div className="col-md-5 m-auto">
                      <div className="card">
                          <div className="card-header bg-success text-white">
                                <p className="h4">Current Counter</p>
                          </div>
                          <div className="card-body bg-light">
                              <form onSubmit={submitUser}>
                                  <div className="form-group">
                                      <input
                                          name='name'
                                          value={user.name}
                                          onChange={handleInput}
                                          type="text" className='form-control' placeholder='Enter Your Name'/>
                                  </div>
                                  <div className="form-group">
                                      <input
                                          name='email'
                                          value={user.email}
                                          onChange={handleInput}
                                          type="email" className='form-control' placeholder='Enter Your Email'/>
                                  </div>
                                  <p onChange={counterChange}  className="h5">Counter : {user.count}</p>


                                  <div className="form-group">
                                      <select required
                                              name='prayerType'
                                              value={user.prayerType}
                                              onChange={handleInput}
                                              className="form-control">
                                          <option>Select Prayer</option>
                                          <option value="MASHAALLAH">Masha Allah</option>
                                          <option value="ALHUMDULILLAH">ALhumdulillah</option>
                                          <option value="JAZAKALLAH">Jazak Allah</option>
                                      </select>
                                  </div>
                                  <div className="form-group mt-3">
                                      <textarea
                                          name='duaDescription'
                                          value={user.duaDescription}
                                          onChange={handleInput}
                                          rows="4" className="form-control" placeholder="Dua Description"/>
                                  </div>
                                  <div className='form-group'>
                                      <input type="submit" className='btn btn-sm btn-success' value="Submit"/>
                                  </div>
                              </form>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </React.Fragment>
  )
};
export default Assignment;