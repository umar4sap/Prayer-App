import React from 'react';
import './App.css';
import Assignment from "./components/Assignment";



let App = () => {
    return (
        <React.Fragment>
            <Assignment/>
        </React.Fragment>
    )
};
export default App;
